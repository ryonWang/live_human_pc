<template>
  <div>
    <clone type="figure"/>
  </div>
</template>

<script setup>
import clone from '@/components/clone/index.vue'
</script>
